
set -e

for project in ./*-*; do
	./random_cluster_checker.py $project
done
